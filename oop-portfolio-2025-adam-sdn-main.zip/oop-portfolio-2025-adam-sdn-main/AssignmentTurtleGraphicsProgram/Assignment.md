[Refer to the assignment spec on myBeckett](https://link-url-here.org](https://drive.google.com/file/d/1ooGVFk3eAOXwvRC950gcW1g2m1jtAKIX/view)https://drive.google.com/file/d/1ooGVFk3eAOXwvRC950gcW1g2m1jtAKIX/view)


[There is useful information in the assignment spec directoty on myBeckett, including help videos](https://my.leedsbeckett.ac.uk/ultra/courses/_167312_1/cl/outline)
