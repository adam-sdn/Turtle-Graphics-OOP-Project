
public class MainClass {
    public static void main(String[] args) {
        TurtleGraphics tg = new TurtleGraphics(); // Launch the TurtleGraphics application


    }
}