[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-22041afd0340ce965d47ae6ef1cefeee28c7c493a6346c4f15d667ab976d596c.svg)](https://classroom.github.com/a/-m6joVjf)

# OOP 2025 Portfolio
## Adam Sweidan
### BSOFTA
### Shakeel Hafiz Mohamed

change "todo" to "completed ontime" or "completed late" when done\
results for each exercise must also be documented in results.md is the relevant directory\

## Work Schedule
**1 Getting Started**\
**committed by 10th February**\
1 Hello World        -- completed on time\
2 Test               -- completed on time\
3 Personal Details   -- completed on time\
4 Diamonds           -- completed on time\
5 Questions          -- completed on time

**2 Data and Expressions**\
**committed by 17th February**\
1 Table of Student Grades  -- completed on time\
2 Computing Averages       -- completed on time\
3 Miles to Kilometers      -- completed on time\
4 Square Calculation       -- completed on time\
5 Fraction -- to do        -- completed on time

**3 Selection and Iteration**\
**committed by 24th February**\
1 Computing a Pay Increase   -- completed on time\
2 Rock, Paper, Scissors      -- completed on time\
3 String Reverser            -- completed on time\
4 Punctuation Marks          -- completed on time

**4 Classes and Objects**\
**committed by 3rd March**\
1 Using String Objects     -- completed on time\
2 Dice                     -- completed on time\
3 Formatting Output        -- completed on time\
4 Pin Encryption           -- completed on time\
5 Sphere Calculation       -- compeleted on time

**5 and 6 Writing Classes and Methods**\
**committed by 17th March**\
1 Sphere       -- completed on time\
2 Books        -- completed on time\
3 Bulb         -- completed on time\
4 Accounts     -- completed on time\
5 Cards        -- completed on time

**7 Inheritance**\
**committed by 24th March**\
1 Hospital            -- completed on time\
2 Player Statistics   -- completed on time

**8 Polymorphism**\
**committed by 31st March**\
1 Firm Vacation           -- completed on time\
2 Password                -- compeleted on time

**9 Further Arrays**\
**committed by 7th April**\
1 Histogram             -- completed on time\
2 L&L Bank Accounts     -- completed on time\
3 Post Codes            -- completed on time\
4 Quiz Time             -- completed on time

**Turtle Graphics Assignment**\
**committed by 5th May 10am**\
1 Basic Application           -- completed on time\
2 Command Processing          -- completed on time\
3 Validating Commands        -- completed on time\
4 Loading and Saving          -- completed on time\
5 Extending OOPGraphics library    -- completed on time\

## Notes

| Type     | Memory  | Description                                        | Example                         |
|----------|--------|------------------------------------------------|--------------------------------|
| `float`  | 4 bytes | Single precision (7 decimal digits), needs `F` suffix | `float price = 5.99F;`        |
| `double` | 8 bytes | Double precision (15-16 decimal digits), default for decimals | `double pi = 3.141592653589793;` |
| `char`   | 2 bytes | Stores a single Unicode character, enclosed in `' '` | `char letter = 'A';`          |
| `boolean`| 1 bit   | Stores only `true` or `false` values                 | `boolean isJavaFun = true;`   |

| Type   | Memory  | Range                             |
|--------|--------|----------------------------------|
| `byte`  | 1 byte  | -128 to 127                     |
| `short` | 2 bytes | -32,768 to 32,767               |
| `int`   | 4 bytes | -2,147,483,648 to 2,147,483,647 |
| `long`  | 8 bytes | -9 quintillion to 9 quintillion |


| Operator | Meaning                  |
|----------|--------------------------|
| ==       | equal to                 |
| !=       | not equal to             |
| <        | less than                |
| <=       | less than or equal to    |
| >        | greater than             |
| >=       | greater than or equal to |


| Operator   | Description                                      | Example | Result                                      |
|------------|--------------------------------------------------|---------|---------------------------------------------|
| `!`        | logical NOT                                      | `!a`    | true if `a` is false and false if `a` is true |
| `&&`       | logical AND                                      | `a && b`| true if `a` and `b` are both true, otherwise false |
| `||`       | logical OR                                       | `a || b`| true if `a` or `b` or both are true, otherwise false |


![image](https://github.com/user-attachments/assets/4ba9762d-771d-44d6-a455-95a22781193b)

![image](https://github.com/user-attachments/assets/d01d47f4-bd88-4834-a2bd-1f399b451503)

![image](https://github.com/user-attachments/assets/d6272b6d-be4e-4ae8-a67b-5d2c01eb2e0c)

![image](https://github.com/user-attachments/assets/1235227c-11bf-4ff9-a031-6a1e035fa692)


![image](https://github.com/user-attachments/assets/49a13022-009d-4140-bb71-c12b5f8cdd2d)







## The small print
The hand in dates for each weekly exercise includes the flexible deadline, as it is two weeks and not one.\
Do not commit again after your hand in deadline.
Enter your details above. Keep your portfolio up to date. You will also store your assignment here.
When you have done an exercise change **-- to do** to **-- completed**.
You can use this file to keep any notes that you may find useful in the phase test.

For each of the exercises create a project in the relevant directory (see myBeckett if you do not know how to do this).
By the end you will have a complete set of projects for the exercises and a project for the assignment in this repo.
For each project you should update results.md file and show the output of your project.
This portfolio is marked and therefore needs to follow these instructions exactly or lose marks.

By submitting this work you are confirming that the work in this repo is your own, with all credit given to any sources of help. Such sources might include software tools.
You also confirm that you have read and understood the regulations relating to academic misconduct.
