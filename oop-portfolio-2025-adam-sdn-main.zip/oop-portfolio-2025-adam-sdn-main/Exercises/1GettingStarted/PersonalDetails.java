public class PersonalDetails
{
    public static void main (String[] args)
    {
     System.out.println ("Name : Bob");
     System.out.println ("Address : 12 ABC Lane");
     System.out.println ("Age : 23");
     System.out.println ("Phone Number : 07985415665");
    }

}
