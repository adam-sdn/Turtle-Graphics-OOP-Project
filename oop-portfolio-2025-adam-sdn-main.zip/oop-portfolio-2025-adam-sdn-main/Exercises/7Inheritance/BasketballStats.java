public class BasketballStats extends PlayerStats{

    int jerseyNumber;
    String team;
    int points;

    public BasketballStats(String firstName, String lastName, int appearance,String nationality, int age , double height, int jerseyNumber ,String team,int points)
    {
        super(firstName, lastName, appearance, nationality, age, height);
        this.jerseyNumber = jerseyNumber;
        this.team = team;
        this.points = points;
    }

    public int getJerseyNumber()
    {
        return jerseyNumber;
    }

    public void setJerseyNumber(int jerseyNumber)
    {
        this.jerseyNumber = jerseyNumber;
    }

    public void printJerseyNumber()
    {
        System.out.println("JERSEY.NO : "+getJerseyNumber());
    }

    public String getTeam()
    {
        return team;
    }

    public void setTeam(String team)
    {
        this.team = team;
    }

    public void printTeam()
    {
        System.out.println("TEAM : "+getTeam());
    }

    public int getPoints()
    {
        return points;
    }

    public void setPoints()
    {
        this.points = points;
    }

    public void printPoints()
    {
        System.out.println("TOTAL POINTS : "+getPoints());
    }
}
