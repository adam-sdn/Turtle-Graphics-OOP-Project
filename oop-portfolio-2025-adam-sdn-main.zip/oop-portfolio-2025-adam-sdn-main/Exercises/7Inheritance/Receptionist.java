public class Receptionist extends Employee {

    int call;


    public Receptionist(String name , String role , String task , double wage , int call)
    {
        super(name, role, task, wage);
        this.call = call;
    }

    public int getCall() {
        return call;
    }

    public void setCall(int call)
    {
        this.call = call;
    }

    public void emergencyCalls()
    {
        System.out.println("The receptionist "+getName()+" has answered "+ getCall()+" call(s) today");
    }
}
