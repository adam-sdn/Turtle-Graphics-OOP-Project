public class PlayerStats {

    String firstName;
    String lastName;
    int appearance;
    String nationality;
    int age;
    double height; //in meters

    public PlayerStats(String firstName, String lastName, int appearance,String nationality, int age , double height)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.appearance = appearance;
        this.nationality = nationality;
        this.age = age;
        this.height = height;
    }

    public String getFirstName()
    {
        return firstName;
    }
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public int getAppearance()
    {
        return appearance;
    }

    public void setAppearance(int appearance)
    {
        this.appearance = appearance;
    }

    public String getNationality()
    {
        return  nationality;
    }

    public void setNationality(String nationality)
    {
        this.nationality = nationality;
    }

    public int getAge()
    {
        return age;
    }

    public void setAge(int age)
    {
        this.age = age;
    }

    public double getHeight()
    {
        return height;
    }

    public void setHeight(double height)
    {
        this.height = height;
    }

    public void printFirstName()
    {
        System.out.println("FIRST NAME : "+getFirstName());
    }

    public void printLastName()
    {
        System.out.println("LAST NAME : "+getLastName());
    }

    public void printAppearance()
    {
        System.out.println("APPEARANCES : "+getAppearance());
    }

    public void printNationality()
    {
        System.out.println("NATIONALITY : "+getNationality());
    }

    public void printAge()
    {
        System.out.println("AGE : "+getAge());
    }

    public void printHeight()
    {
        System.out.println("HEIGHT : "+getHeight());
    }
}
