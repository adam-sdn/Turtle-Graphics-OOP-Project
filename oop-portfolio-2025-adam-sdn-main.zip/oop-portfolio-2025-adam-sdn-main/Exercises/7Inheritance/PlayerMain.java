public class PlayerMain {

    public static void main(String[] args)
    {
        FootballStats Ronaldo = new FootballStats("Cristiano","Ronaldo",1200,"Portugal",40,1.89,"Al Nassar",257,928,"ST / Striker");
        BasketballStats Lebron = new BasketballStats("Lebron","James",1421,"USA",40,2.06,23,"Los Angeles Lakers",46675);

        System.out.println("FOOTBALL PLAYER STATS : ");

        System.out.println();

        // All of the Football playerss stats set up here
        Ronaldo.printFirstName();
        Ronaldo.printLastName();
        Ronaldo.printAppearance();
        Ronaldo.printNationality();
        Ronaldo.printAge();
        Ronaldo.printHeight();
        Ronaldo.printFootballClub();
        Ronaldo.printAssists();
        Ronaldo.printGoals();
        Ronaldo.printPosition();

        System.out.println();

        System.out.println("BASKETBALL PLAYER STATS : ");

        Lebron.printFirstName();
        Lebron.printLastName();
        Lebron.printAppearance();
        Lebron.printNationality();
        Lebron.printAge();
        Lebron.printHeight();
        Lebron.printJerseyNumber();
        Lebron.printTeam();
        Lebron.printPoints();

    }
}
