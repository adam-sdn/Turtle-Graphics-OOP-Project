public class Nurse extends Employee{

    int patient;
    public Nurse(String name, String role , String task , double wage, int patient)
    {
        super(name,role,task,wage);
        this.patient = patient;
    }

    public int getPatient()
    {
        return patient;
    }

    public void setPatient(int patient)
    {
        this.patient = patient;
    }

    public void patientNo()
    {
        System.out.println("Nurse "+getName()+" looks after a total of "+getPatient()+" patient(s)");
    }
}
