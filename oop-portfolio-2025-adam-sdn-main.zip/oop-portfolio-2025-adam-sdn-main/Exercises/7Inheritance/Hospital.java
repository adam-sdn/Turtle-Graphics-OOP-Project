public class Hospital {

    public static void main(String[] args)
    {
        Doctor doctor = new Doctor("Adam","Surgeon","Diagnose patients",14000000.85,"Neurosurgery");
        Nurse nurse = new Nurse("Heather","Assistant Nurse","Take care of patients",40000.99,20);
        Cleaner cleaner = new Cleaner("Bob","Ward Cleaner","Keep Ward clean",25000,'A');
        Receptionist receptionist = new Receptionist("Mariam","Main Receptionist","Answer Emergency calls",45000,45);

        doctor.Name();
        doctor.Wage();
        doctor.specialised();

        System.out.println();

        nurse.Name();
        nurse.Wage();
        nurse.patientNo();

        System.out.println();

        cleaner.Name();
        cleaner.Wage();
        cleaner.wardBuilding();

        System.out.println();

        receptionist.Name();
        receptionist.Wage();
        receptionist.emergencyCalls();




    }


}
