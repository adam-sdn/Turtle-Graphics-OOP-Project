public class Cleaner extends Employee {

    char ward;

    public Cleaner(String name , String role , String task , double wage , char ward)
    {
        super(name, role, task, wage);
        this.ward = ward;
    }

    public char getWard()
    {
        return ward;
    }

    public void setWard(char ward)
    {
        this.ward = ward;
    }

    public void wardBuilding()
    {
        System.out.println("The cleaner "+getName()+" is set at Ward "+getWard());
    }
}
