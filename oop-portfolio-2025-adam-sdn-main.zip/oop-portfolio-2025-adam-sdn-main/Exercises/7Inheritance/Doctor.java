public class Doctor extends Employee {

    String specialty;
    public Doctor(String name, String role , String task , double wage, String specialty)
    {
        super(name,role,task,wage);
        this.specialty = specialty;
    }

    public void setSpecialty(String specialty)
    {
        this.specialty = specialty;
    }

    public String getSpecialty()
    {
        return specialty;
    }

    public void specialised()
    {
        System.out.println("Dr."+getName()+" is specalised in "+getSpecialty());
    }
}
