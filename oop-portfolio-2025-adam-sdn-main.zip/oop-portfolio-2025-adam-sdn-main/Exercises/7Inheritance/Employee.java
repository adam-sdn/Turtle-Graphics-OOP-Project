public class Employee {

    public String name;
    public String role;
    public String task;
    public double wage;

    public Employee(String name,String role, String task , double wage)
    {
        this.role = role;
        this.task = task;
        this.wage = wage;
        this.name = name;
    }

    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getRole()
    {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public String getTask()
    {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }

    public double getWage() {
        return wage;
    }

    public void setWage(double wage) {
        this.wage = wage;
    }

    public void Role()
    {
        System.out.println("ROLE : "+role);
    }

    public void Task()
    {
        System.out.println("TASK : "+task);
    }

    public void Wage()
    {
        System.out.println("WAGE : £ "+wage);
    }

    public void Name()
    {
        System.out.println("NAME : "+name);
    }



}
