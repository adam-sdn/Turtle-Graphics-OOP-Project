public class FootballStats extends PlayerStats{

    String footballClub;
    int assists;
    int goals;
    String position;

    public FootballStats(String firstName, String lastName, int appearance,String nationality, int age , double height,String footballClub,int assists,int goals,String position)
    {
        super(firstName,lastName,appearance,nationality,age,height);
        this.footballClub = footballClub;
        this.assists = assists;
        this.goals = goals;
        this.position = position;

    }

    public String getFootballClub()
    {
        return footballClub;
    }

    public void setFootballClub(String footballClub)
    {
        this.footballClub = footballClub;
    }

    public int getAssists()
    {
        return assists;
    }

    public void setAssists(int assists)
    {
        this.assists = assists;
    }

    public int getGoals()
    {
        return goals;
    }

    public void setGoals(int goals)
    {
        this.goals = goals;
    }

    public String getPosition()
    {
        return position;
    }

    public void setPosition(String position)
    {
        this.position = position;
    }

    public void printFootballClub()
    {
        System.out.println("CLUB : "+getFootballClub());
    }

    public void printAssists()
    {
        System.out.println("ASSIST.NO : "+getAssists());
    }

    public void printGoals()
    {
        System.out.println("GOAL.NO : "+getGoals());
    }

    public void printPosition()
    {
        System.out.println("POSITION : "+getPosition());
    }
}
