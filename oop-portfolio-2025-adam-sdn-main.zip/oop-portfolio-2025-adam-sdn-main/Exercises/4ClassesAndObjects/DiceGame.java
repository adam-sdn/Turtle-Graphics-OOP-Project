import java.util.Scanner;

public class DiceGame {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);


        System.out.println("How many sides does die 1 have?: ");
        int sides1 = scanner.nextInt();

        System.out.println("Now how many sides does die 2 have?: ");
        int sides2 = scanner.nextInt();


        Dice die1 = new Dice(sides1);
        Dice die2 = new Dice(sides2);


        int[] rolls1 = new int[3];
        int[] rolls2 = new int[3];

        for (int i = 0; i < 3; i++) {
            rolls1[i] = die1.roll();
            rolls2[i] = die2.roll();
        }

        System.out.println("Die 1 first roll: " + rolls1[0]);
        System.out.println("Die 1 second roll: " + rolls1[1]);
        System.out.println("Die 1 third roll: " + rolls1[2]);

        System.out.println("-------------------------------"); //I added these lines to seperate the dice 1 rolls from the dice 2 rolls

        System.out.println("Die 2 first roll: " + rolls2[0]);
        System.out.println("Die 2 second roll: " + rolls2[1]);
        System.out.println("Die 2 third roll: " + rolls2[2]);

        System.out.println("-------------------------------");

        int total1 = rolls1[0] + rolls1[1] + rolls1[2];
        int average1 = total1 / 3;

        int total2 = rolls2[0] + rolls2[1] + rolls2[2];
        int average2 = total2 / 3;

        System.out.println("The total Die 1 rolled is: " + total1);
        System.out.println("The average of Die 1 is: " + average1);
        System.out.println("The total Die 2 rolled is: " + total2);
        System.out.println("The average of Die 2 is: " + average2);
    }
}