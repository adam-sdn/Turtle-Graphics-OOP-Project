import java.util.Random;
import java.util.Scanner;

public class Encryption {
        int pin;
        int number;
        int number2;
        String H_number1;
        String H_number2;


    String Pin_no(){
        return Integer.toHexString(pin);
    }

    String Hex1(){
        Random r = new Random();
        number = r.nextInt(1000,65537);
        H_number1 = Integer.toHexString(number);
        return H_number1;


    }

    String Hex2(){
        Random r = new Random();
        number2 = r.nextInt(1000,65537);
        H_number2 = Integer.toHexString(number2);
        return H_number2;
    }

    public static void main(String[] args){

        Scanner s = new Scanner(System.in);
        Random r = new Random();
        Encryption e = new Encryption();

        System.out.println("Enter your 4 digit Pin : ");
         e.pin = s.nextInt();

        System.out.println("Processsing..."); // Just to give it a spice of the real world haha

        String Hexpin = e.Pin_no();
        String HexRandom1 = e.Hex1();
        String HexRandom2 = e.Hex2();
        String Encrypt = HexRandom1.concat(Hexpin+HexRandom2);

        System.out.println("Your encrypted pin number is :  " + Encrypt);

    }
}
