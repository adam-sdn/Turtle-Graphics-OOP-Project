import java.util.Scanner;

public class Circle {

    double radius; // The radius can be a decimal , which is why it cannot be an integer



    double Volume(){
        return 4*Math.PI*Math.pow(radius,3)/3;
    }

    double Surface(){
        return 4*Math.PI*Math.pow(radius,2);
    }

    public static void main(String[] args){
        Scanner s = new Scanner(System.in);
        Circle  c = new Circle();

        System.out.println("Please enter the radius of your sphere in meters:");
        c.radius = s.nextDouble();

        System.out.println("Processing..."); //This just makes it look like its working to find the answer

        System.out.println("The Volume of your sphere is : " +c.Volume()+" m3"); //borrowed the units of wiktionary
        System.out.println("The Surface Area of your sphere is:  "+c.Surface()+" m²");



    }
}
