import java.util.Scanner;
public class Fraction {

    public static void main (String[] args){
        Scanner scan = new Scanner(System.in);

        System.out.println("Please enter the following values to convert your fraction into decimal");

        System.out.println("Enter the integer of your numerator :");
        int numerator = scan.nextInt();

        System.out.println("Now enter the integer of your denominator :");
        int denominator = scan.nextInt();

        double decimal = (double) numerator/denominator;
        System.out.println("The value of your faction as a decimal is :" +
                "\n "+ decimal);
    }
}
