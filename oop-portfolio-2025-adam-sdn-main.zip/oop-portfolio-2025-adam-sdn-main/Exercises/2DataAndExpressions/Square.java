import java.util.Scanner;
public class Square {
    public static void main(String[] args){
        Scanner scan = new Scanner(System.in);

        System.out.println("Please enter the length of your square :");

        double length = scan.nextDouble();
        double perimeter = length*4;
        double area = length*length;

        System.out.println("Here are the following calculations :" +
                "\n Perimeter of your square:  "+perimeter+
                "\n Area of your square:  "+area);
    }
}

