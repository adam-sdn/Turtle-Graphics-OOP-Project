public class StudentGrades
{
 public static void main(String[] args){

     byte Adam_lab = 43;
     byte Adam_bonus = 7;
     byte Adam_Total = (byte) (Adam_bonus + Adam_lab);

     byte Bob_lab = 50;
     byte Bob_bonus = 8;
     byte Bob_Total = (byte) (Bob_bonus + Bob_lab);

     byte Mary_lab = 39;
     byte Mary_bonus = 10;
     byte Mary_Total = (byte) (Mary_bonus + Mary_lab);

     byte Harry_lab = 25;
     byte Harry_bonus = 5;
     byte Harry_Total = (byte) (Harry_bonus + Harry_lab);

     byte James_lab = 27;
     byte James_bonus = 4;
     byte James_Total = (byte) (James_bonus + James_lab);

     System.out.println("///////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\n" +
             "==          Student Points          ==\n" +
             "\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\///////////////////");

     System.out.println("Name            Lab     Bonus   Total\n" +
             "----            ---     -----   -----");

     System.out.println("Adam         "+Adam_lab+"         "+Adam_bonus+"       "+Adam_Total);
     System.out.println("Bob          "+Bob_lab+"         "+Bob_bonus+"       "+Bob_Total);
     System.out.println("Mary         "+Mary_lab+"        "+Mary_bonus+"       "+Mary_Total);
     System.out.println("Harry        "+Harry_lab+"        "+Harry_bonus+"       "+Mary_Total);
     System.out.println("James        "+James_lab+"        "+James_bonus+"       "+James_Total);

 }
}
