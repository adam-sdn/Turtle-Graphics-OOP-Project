import java.util.Scanner;
public class MilesConverter {

    public static void main (String[] args){

        Scanner scan = new Scanner(System.in);
        System.out.println("I will convert Miles to Kilometers ");
        System.out.println("Please enter your distance in miles :");

        double miles = scan.nextDouble();
        double km = miles*1.60935;

        System.out.println("Your distance in kilometers is  "+km+"km");
    }

}

