import java.util.Scanner;
public class Reverser {
    public static void main(String[] args) {

        Scanner scan = new Scanner(System.in);

        System.out.println("Enter the string you want reversed :");
        String input = scan.nextLine();
        // A place so that I can store the string that is being reversed
        String results = "";

        for(int i = input.length()-1; i >=0 ; i-- )
        {


            // This will add the letters starting from the end
            results += input.charAt(i);
        }

        System.out.println("Your String reversed is :" +
                "\nOriginal : "+input+"" +
                "\nReversed : "+results);  // I added a feature where it will compare the orginal string with the reversed one


    }
}
