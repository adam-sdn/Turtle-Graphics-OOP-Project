
public class Punctuation
{
    public static void main(String[] args)
    {
        String poem = "Mary had a little lamb," +
                "\nher fleece was as white as snow," +
                "\n and everywhere Mary went," +
                "\nthe lamb was sure to go." +
                "\n-that was a nice poem- the end. ";

        int e_mark = 0;
        int q_mark = 0;
        int fullstop = 0;
        int comma = 0;

        for (int i = 0; i < poem.length(); i++)
        {
            //This is to check if the character in the string is a punctuation or not
            char punct = poem.charAt(i);


            if (punct == '!')
            {
                e_mark++;
            }

            else if (punct == '?')
            {
                q_mark++;
            }

            else if (punct == '.')
            {
                fullstop++;
            }

            else if (punct == ',')
            {
                comma++;
            }


        }
        //Drawing out the table with lines and headings
        System.out.println("The following punctuations were used in the poem :");
        System.out.println("--------------------------------------------------");
        System.out.println("      PUNCTUATION       ||        OCCURENCE        ");
        System.out.println("--------------------------------------------------");
        System.out.println("Explanation Mark '!'"+"                "+e_mark);
        System.out.println("Question Mark '?' "+"                  "+q_mark);
        System.out.println("Fullstops '.'       "+"                "+fullstop);
        System.out.println("Commas ','            "+"              "+comma);
    }
}
