import java.util.Random;

public class MainCard {

    public static void main(String[] args)
    {
        Card card1 = new Card("Hearts","7");
        Card card2 = new Card("Diamond","4");
        Card card3 = new Card("Spades","King");
        Card card4 = new Card("Clubs","8");
        Card card5 = new Card("Hearts","Queen");

        System.out.println("Your first 5 cards drawn are : "+"\n"+
                "Suit"+"  "+"Face Value"+"\n"+
                card1.getSuit()+"   "+card1.getFaceValue()+"\n"+
                card2.getSuit()+"  "+card2.getFaceValue()+"\n"+
                card3.getSuit()+"   "+card3.getFaceValue()+"\n"+
                card4.getSuit()+"    "+card4.getFaceValue()+"\n"+
                card5.getSuit()+"   "+card5.getFaceValue());

        System.out.println();
        System.out.println();
        System.out.println("Generating new cards for you...");
        System.out.println();
        System.out.println();

        // These will give us new Suit values for each card
        card1.newSuit();
        card2.newSuit();
        card3.newSuit();
        card4.newSuit();
        card5.newSuit();

        // And these will give us new Face Values for each card
        card1.newFaceValue();
        card2.newFaceValue();
        card3.newFaceValue();
        card4.newFaceValue();
        card5.newFaceValue();

        System.out.println("Your new 5 cards are : "+"\n"+
                "Suit"+"  "+"Face Value"+"\n"+
                card1.getSuit()+"      "+card1.getFaceValue()+"\n"+
                card2.getSuit()+"      "+card2.getFaceValue()+"\n"+
                card3.getSuit()+"      "+card3.getFaceValue()+"\n"+
                card4.getSuit()+"      "+card4.getFaceValue()+"\n"+
                card5.getSuit()+"      "+card5.getFaceValue());
    }
}
