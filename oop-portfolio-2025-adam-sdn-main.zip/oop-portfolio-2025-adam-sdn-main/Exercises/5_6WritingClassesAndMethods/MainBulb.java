public class MainBulb {

    public static void main (String[] args)
    {
        Bulb Bulb1 = new Bulb(true);
        Bulb Bulb2 = new Bulb(true);
        Bulb Bulb3 = new Bulb(false);

        System.out.println("Bulb 1 : "+Bulb1.on_off_Switch()+
                "\n\nBulb 2 : "+Bulb2.on_off_Switch()+
                "\n\nBulb 3 : "+Bulb3.on_off_Switch());

        System.out.println(" ");
        System.out.println(" ");
        System.out.println(" ");

        System.out.println("Changing the Bulb's switches..."); //To show that the light bulbs are being changed

        Bulb1.setSwitch(false);
        Bulb2.setSwitch(true);
        Bulb3.setSwitch(true);

        System.out.println("The light bulbs are now :");

        System.out.println(" ");


        System.out.println("Bulb 1 : "+Bulb1.on_off_Switch()+
                "\n\nBulb 2 : "+Bulb2.on_off_Switch()+
                "\n\nBulb 3 : "+Bulb3.on_off_Switch());

    }
}

