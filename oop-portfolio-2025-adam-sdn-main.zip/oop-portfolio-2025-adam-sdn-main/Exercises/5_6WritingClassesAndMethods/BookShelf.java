
public class BookShelf
{
    public static void main(String[] args)
    {
        BookData book = new BookData("To Kill a Mockingbird","Harper Lee","J.B. Lippincott & Co.","01/01/1960");

        System.out.println(book);

        System.out.println(" ");


        System.out.println("Loading a new book..."); //Just for user experience

        System.out.println(" ");

        book.setTitle("1984");
        book.setAuthor("George Orwell");
        book.setPublisher("Secker & Warburg");
        book.setDate("08/06/1949");

        System.out.println(book);

    }
}
