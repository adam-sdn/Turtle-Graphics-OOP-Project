public class Sphere{
    double diameter;

    public  Sphere(double diameter)
    {
        this.diameter = diameter;
    }

    public void setDiameter(double diameter)
    {
        this.diameter = diameter;
    }

    public double getDiameter()
    {
        return diameter;
    }

    public double Volume()
    {
     double radius = diameter/2;
     return (4.0/3.0)*Math.PI*Math.pow(radius,3);
    }

    public double SurfaceArea()
    {
        double radius = diameter/2;
        return 4*Math.PI*Math.pow(radius,2);
    }

    @Override
    public String toString() {
        return "The radius of Sphere 1 is :"+" "+diameter/2;
    }
}
