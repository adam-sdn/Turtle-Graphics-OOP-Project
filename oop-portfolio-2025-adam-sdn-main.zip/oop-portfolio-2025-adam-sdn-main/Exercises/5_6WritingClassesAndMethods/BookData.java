import java.time.LocalDate;

public class BookData
{
    String title;
    String author;
    String publisher;
    String date;

    public BookData(String title, String author, String publisher, String date)
    {
        this.title = title;
        this.author = author;
        this.publisher = publisher;
        this.date = date;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public String getTitle()
    {
        return title;
    }

    public void setAuthor(String author)
    {
        this.author = author;
    }

    public String getAuthor(String author)
    {
        return author;
    }

    public void setPublisher(String publisher)
    {
        this.publisher = publisher;
    }

    public String getPublisher(String publisher) // I am not sure where and when to use the getters
    {
        return publisher;
    }

    public void setDate(String date)
    {
        this.date = date; //in dd-MM-YY format
    }

    public String getDate()
    {
        return date;
    }

    public String toString()
    {
        return "Book information\n" +
                "Title : "+ title+"\n" +
                "Author : "+ author+"\n" +
                "Publisher : "+publisher+"\n" +
                "Copyright Date : "+date;
    }
}
