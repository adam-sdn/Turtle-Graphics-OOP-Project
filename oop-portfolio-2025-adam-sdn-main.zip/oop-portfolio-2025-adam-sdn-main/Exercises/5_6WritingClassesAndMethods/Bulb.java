public class Bulb{

    boolean Switch;

    public Bulb(boolean Switch)
    {
        this.Switch = Switch;
    }

    public void setSwitch(boolean Switch)
    {
        this.Switch = Switch;
    }

    public boolean getSwitch()
    {
        return Switch;
    }

    public String on_off_Switch()
    {

        if (Switch)
        {
         return "ON";
        }
        else
        {
            return "OFF";
        }
    }


}
