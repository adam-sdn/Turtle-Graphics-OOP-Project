//********************************************************************
//  Transactions.java       Java Foundations
//
//  Demonstrates the creation and use of multiple Account objects.
//********************************************************************

public class Transactions
{
    //-----------------------------------------------------------------
    //  Creates some bank accounts and requests various services.
    //-----------------------------------------------------------------
    public static void main (String[] args)
    {
        Account acct1 = new Account ("Ted Murphy", 72354, 25.59);
        Account acct2 = new Account ("Angelica Adams", 69713, 500.00);
        Account acct3 = new Account ("Edward Demsey", 93757, 769.32);
        Account acct4 = new Account("Lebron James",65148); // I added a 4th account to demonstrate that an object can have no balance inputted and still be processed as required

        acct1.deposit (44.10);  // return value ignored

        System.out.println("James' initial balance is : "+"£"+ //Added the GBP sign as well
                acct4.getBalance()); // Will print 0 since not initial balance was inputted


        double lebronJamesBalance = acct4.deposit(100000.86);


        System.out.println("James' balance after deposit : "+"£"
                +lebronJamesBalance); //Same value as whatever the deposit is since the balnce is zero from the start

        System.out.println();

        double adamsBalance = acct2.deposit (75.25);
        System.out.println ("Adams balance after deposit: " +"£"+
                adamsBalance);

        System.out.println ("Adams balance after withdrawal : " +"£"+
                acct2.withdraw (480, 1.50));

        acct3.withdraw (-100.00, 1.50);  // invalid transaction

        acct1.addInterest();
        acct2.addInterest();
        acct3.addInterest();

        System.out.println ();
        System.out.println (acct1);
        System.out.println (acct2);
        System.out.println (acct3);
        System.out.println(acct4); // I also added the account to the final list
    }
}
