import java.util.Random;

public class MultiSphere {

    public static void main(String[] args) {

        Sphere sphere1 = new Sphere(10.5);
        Sphere sphere2 = new Sphere(4.7);
        Sphere sphere3 = new Sphere(9);
        Random r = new Random();


        //As before the units are taken from Wikipedia (idk how to do it on keyboard)
        System.out.println("Intial Diameter of Sphere 1 : " + sphere1.getDiameter() + " cm");
        System.out.println("Initial Volume of Sphere 1 : " + sphere1.Volume() + " cm³");
        System.out.println("Initial Surface Area of Sphere 1 : " + sphere1.SurfaceArea() + " cm²");

        System.out.println("------------------------------------------------------------------"); //Just to make it look neat

        System.out.println("Intial Diameter of Sphere 2 : " + sphere2.getDiameter() + " cm");
        System.out.println("Initial Volume of Sphere 2 : " + sphere2.Volume() + " cm³");
        System.out.println("Initial Surface Area of Sphere 2 : " + sphere2.SurfaceArea() + " cm²");

        System.out.println("------------------------------------------------------------------");

        System.out.println("Intial Diameter of Sphere 3 : " + sphere3.getDiameter() + " cm");
        System.out.println("Initial Volume of Sphere 3 : " + sphere3.Volume() + " cm³");
        System.out.println("Initial Surface Area of Sphere 3 : " + sphere3.SurfaceArea() + " cm²");

        System.out.println("                                                                 ");
        System.out.println("                                                                 ");
        System.out.println("                                                                 ");

        // I added a random feature so that you dont have to manually change the diameter
        sphere1.setDiameter(r.nextDouble(0, 100));
        sphere2.setDiameter(r.nextDouble(0, 100));
        sphere3.setDiameter(r.nextDouble(0, 100));

        System.out.println("The diameter of Sphere 1 is now set to : " + sphere1.getDiameter() + " cm");
        System.out.println("The diameter of Sphere 2 is now set to : " + sphere2.getDiameter() + " cm");
        System.out.println("The diameter of Sphere 3 is now set to : " + sphere3.getDiameter() + " cm");

        System.out.println("The new Volume of Sphere 1 is :  " + sphere1.Volume() + " cm³");
        System.out.println("The new Surface Area of Sphere 1 is : " + sphere1.SurfaceArea() + " cm²");

        System.out.println("--------------------------------------------------------");

        System.out.println("The new Volume of Sphere 2 is :  " + sphere2.Volume() + " cm³");
        System.out.println("The new Surface Area of Sphere 2 is : " + sphere2.SurfaceArea() + " cm²");

        System.out.println("--------------------------------------------------------");

        System.out.println("The new Volume of Sphere 3 is :  " + sphere2.Volume() + " cm³");
        System.out.println("The new Surface Area of Sphere 3 is : " + sphere3.SurfaceArea() + " cm²");

        System.out.println("                                                                 ");
        System.out.println("                                                                 ");
        System.out.println("                                                                 ");

        //I was unsure what the 4th point exactly wanted so I assumed it was something like this
        System.out.println("Did you know ? :\n" + sphere1.toString() + " cm");

    }
}
