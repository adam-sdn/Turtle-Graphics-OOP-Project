import java.util.Random;

public class Card {

    Random r = new Random();

    String Suit;
    String FaceValue;

    public Card(String Suit , String FaceValue)
    {
        this.FaceValue = FaceValue;
        this.Suit = Suit;
    }

    public void setSuit(String Suit)
    {
        this.Suit = Suit;
    }

    public String getSuit()
    {
        return Suit;
    }

    public void setFaceValue(String faceValue) {
        FaceValue = faceValue;
    }

    public String getFaceValue() {
        return FaceValue;
    }

    public String newSuit()
    {
        Random r = new Random();
        String[] randomSuit = {"Hearts","Diamonds","Clubs","Spades"};
        this.Suit = randomSuit[r.nextInt(randomSuit.length)]; //I used arrray indexing and .length keyword to randomly pick a suit's value
        return Suit;

    }

    public String newFaceValue()
    {
        Random r = new Random();
        String[] randomFaceValue = {"Ace","2","3","4","5","6","7","8","9","10","Jack","Queen","King"};
        this.FaceValue = randomFaceValue[r.nextInt(randomFaceValue.length)];
        return FaceValue;
    }
}
