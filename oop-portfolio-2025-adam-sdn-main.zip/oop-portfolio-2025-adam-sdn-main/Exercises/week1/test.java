package Exercises.week1;

public class test
{
    //----------------------------------------------------
    //  Prints a statement.
    //----------------------------------------------------
    public static void main (String[] args)
    {
        System.out.println ("An emergency Broadcast");
    }
}
