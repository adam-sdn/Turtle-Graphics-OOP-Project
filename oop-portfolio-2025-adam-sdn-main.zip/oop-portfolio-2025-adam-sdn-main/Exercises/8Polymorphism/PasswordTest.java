import java.util.Scanner;

public class PasswordTest {
    public static void main (String[] args)
    {
        Scanner s = new Scanner(System.in);

        System.out.println("Enter your Password : ");
        String pass = s.nextLine();

        Password password = new Password(pass); // I had to create the password object right after the user inputs their passwords so i can put in a parameter
        Secret secret = new Secret(pass);


        System.out.println("Password being encrypted..."); //Adding this for user expereicene

        password.encrypt(); //encrypt the password of the user
        password.printEncrypted(); // Print out the encrypted password

        secret.encrypt();
        System.out.println("Encrypted Message using Cipher Caeser is : "+secret.toString());

        System.out.println();

        password.decrypt();
        password.printDecrypt();

        secret.decrypt();
        System.out.println("Your Cipher Caesered password decrypted is : "+secret.toString());
    }
}
