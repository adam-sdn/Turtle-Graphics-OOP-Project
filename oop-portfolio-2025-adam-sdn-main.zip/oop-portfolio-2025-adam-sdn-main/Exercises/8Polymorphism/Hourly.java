//********************************************************************
//  Hourly.java       Java Foundations
//  Represents an employee paid by the hour.
//********************************************************************
public class Hourly extends Employees
{
    private int hoursWorked;

    public Hourly(String eName, String eAddress, String ePhone,
                  String socSecNumber, double rate)
    {
        super(eName, eAddress, ePhone, socSecNumber, rate);
        hoursWorked = 0;
    }

    public void addHours(int moreHours)
    {
        hoursWorked += moreHours;
    }

    public double pay()
    {
        double payment = payRate * hoursWorked;
        hoursWorked = 0;
        return payment;
    }

    public int vacationDays()
    {
        return 7;
    }
}
