//********************************************************************
//  Volunteer.java       Java Foundations
//  Represents a volunteer staff member.
//********************************************************************
public class Volunteer extends StaffMember
{
    public Volunteer(String eName, String eAddress, String ePhone)
    {
        super(eName, eAddress, ePhone);
    }

    public double pay()
    {
        return 0.0;
    }

    public int vacationDays()
    {
        return 0;
    }
}
