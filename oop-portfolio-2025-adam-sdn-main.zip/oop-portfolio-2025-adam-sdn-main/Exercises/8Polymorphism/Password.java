public class Password implements Encryptable{
    // I implemented the encryptable interface into the password so that there is an  encrypt and decrpyting method in the password class
    String password;
    String encrypted;
    String decrypted;



    public Password(String password)
    {
        this.password =password;
        this.encrypted = "";
        this.decrypted = "";
    }
    @Override
    public void encrypt()
    {
        StringBuilder encrypted = new StringBuilder(); // I needed to created a StringBuilder so that I can add the characters into one whole new string since it is mutable
        char[] encrypt = password.toCharArray(); // I made the password an array of characteres so that each character can be changed individually (encrypted individually)

        for(char i : encrypt)
        {
            i +=7; // Shifting the characters by 7 positions
            encrypted.append(i);
        }
        this.encrypted = encrypted.toString(); //Add all the characters toghether into a string and store it into the instance
    }

    public String getEncrypted() {
        return encrypted;  // Get the encrypted value
    }

    public void printEncrypted()
    {
        System.out.println("Encrypted Password  is now set to : "+getEncrypted());
    }

    @Override
    public String decrypt()
    {
        StringBuilder decryption = new StringBuilder();
        char[] decrypt = encrypted.toCharArray(); // Same as encrypted but for decrypted

        for(char i : decrypt)
        {
            i -=7; // Move back 7 positions since the encryption went forward 7 . Were basically reversing it back
            decryption.append(i); //adding the characters to the decrypted string
        }

        this.decrypted = decryption.toString(); // putting all the characters into one string
        return decrypted;
    }

    public void printDecrypt()
    {
        System.out.println("Your Decrypted password is : "+decrypted);
    }
}
