//********************************************************************
//  Executive.java       Java Foundations
//  Represents an executive staff member.
//********************************************************************
public class Executive extends Employees
{
    private double bonus;

    public Executive(String eName, String eAddress, String ePhone,
                     String socSecNumber, double rate)
    {
        super(eName, eAddress, ePhone, socSecNumber, rate);
        bonus = 0;
    }

    public void awardBonus(double execBonus)
    {
        bonus = execBonus;
    }

    public double pay()
    {
        double payment = super.pay() + bonus;
        bonus = 0;
        return payment;
    }

    public int vacationDays()
    {
        return 21; //Added more for the executive since they are the booss
    }
}