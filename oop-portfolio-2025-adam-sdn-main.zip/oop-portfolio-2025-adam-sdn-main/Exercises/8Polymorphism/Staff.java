public class Staff
{
    private StaffMember[] staffList;

    public Staff()
    {
        staffList = new StaffMember[6];
        staffList[0] = new Executive("Tony", "123 Main Line", "07689412114", "123-45-6789", 2423.07);
        staffList[1] = new Employees("Paul", "456 Main Road", "07986514442", "987-65-4321", 1246.15);
        staffList[2] = new Employees("Vincet", "54 Wellington Street", "07651232963", "010-20-3040", 1169.23);
        staffList[3] = new Hourly("Michael", "99 Leeds Road", "07632114896", "958-47-3625", 10.55);
        staffList[4] = new Volunteer("Adrianna", "10 Downing Street", "07320021458");
        staffList[5] = new Volunteer("Bob", "8 Manhattan Lane", "07632987774");

        ((Executive)staffList[0]).awardBonus(500.00);
        ((Hourly)staffList[3]).addHours(40);
    }

    public void payday()
    {
        double amount;
        for (StaffMember member : staffList)
        {
            System.out.println(member);
            amount = member.pay();
            System.out.println("Paid: " + amount);
            System.out.println("Vacation Days: " + member.vacationDays());
            System.out.println("-----------------------------------"); //Repeating the setout here rather than doing it on the main function which takes time
        }
    }
}
