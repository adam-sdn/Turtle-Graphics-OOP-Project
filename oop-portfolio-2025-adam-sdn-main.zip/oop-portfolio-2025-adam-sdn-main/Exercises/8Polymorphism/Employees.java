//********************************************************************
//  Employee.java       Java Foundations
//  Represents a general paid employee.
//********************************************************************
public class Employees extends StaffMember
{
    protected String socialSecurityNumber;
    protected double payRate;

    public Employees(String eName, String eAddress, String ePhone,
                     String socSecNumber, double rate)
    {
        super(eName, eAddress, ePhone);
        socialSecurityNumber = socSecNumber;
        payRate = rate;
    }

    public String toString()
    {
        return super.toString() + "\nSocial Security Number: " + socialSecurityNumber;
    }

    public double pay()
    {
        return payRate;
    }

    public int vacationDays()
    {
        return 14 ; // I set this as the default days an employee can have for thier holiday
    }
}