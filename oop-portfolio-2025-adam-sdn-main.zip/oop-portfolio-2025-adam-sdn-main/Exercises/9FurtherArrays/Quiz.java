import java.util.ArrayList;
import java.util.Scanner;

public class Quiz {


    ArrayList <QuestionInput> questionInputs;
    int questionScore= 0 ; //To add up the question that are being inputted and keeping a record of them

    Scanner s = new Scanner(System.in);

    public Quiz()
    {
        questionInputs = new ArrayList<>(); //I initiallised the Arraylist
    }

    public void addQuestion(QuestionInput question)
    {
        if(questionInputs.size() < 25) //This is to make sure that the question bank never goes more than 25 questions above
        {
            questionInputs.add(question);
        }
        else
        {
            System.out.println("You have exceeded the amount of questions allowed please try again"); //To indicate to the user that they cant add more questions anymore
        }
    }

    public void giveQuiz()
    {
        for(int i = 0 ; i < questionInputs.size() ; i++)
        {
            System.out.println("Question : "+questionInputs.get(i).getQuestion()); //Giving the question to the user
            System.out.println("Answer : ");
            String userAnswer = s.nextLine();

            if (questionInputs.get(i).AnswerValid(userAnswer))
            {
                questionScore++; //add the score
            }

            System.out.println("Your Score : "+questionScore);
        }
    }
}
