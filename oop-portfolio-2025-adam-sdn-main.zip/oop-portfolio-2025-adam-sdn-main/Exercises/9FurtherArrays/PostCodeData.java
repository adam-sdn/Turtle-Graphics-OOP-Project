public class PostCodeData {

    String firstName;
    String lastName;
    String PostCode;

    public PostCodeData(String firstName , String lastName , String PostCode)
    {
        this.firstName = firstName;
        this.lastName = lastName;
        this.PostCode = PostCode;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName()
    {
        this.firstName = firstName;
    }

    public void printFirstName()
    {
        System.out.print("First Name : "+getFirstName()+" | ");
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName()
    {
        this.lastName = lastName;
    }

    public void printLastName()
    {
        System.out.print("Last Name  : "+getLastName()+" | ");
    }

    public String getPostCode()
    {
        return PostCode;
    }

    public void setPostCode()
    {
        this.PostCode = PostCode;
    }

    public void printPostCode()
    {
        System.out.println("POSTCODE : "+getPostCode()+" | ");
    }
}
