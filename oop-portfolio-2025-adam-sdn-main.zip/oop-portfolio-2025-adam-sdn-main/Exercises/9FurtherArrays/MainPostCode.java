import java.util.Scanner;

public class MainPostCode {

    public static void main (String[] args)
    {
        Scanner s = new Scanner(System.in);

        PostCodeData p1 = new PostCodeData("Harry","Maguire","LS5 1LP");
        PostCodeData p2 = new PostCodeData("Antony","Smith","LS9 PBW");
        PostCodeData p3 = new PostCodeData("James","Lloyd","LS1 RS3");

        PostCodeData[] postcodes = new PostCodeData[27]; //Since i already used 3 spots meaning there are up to 25 spots left as required
        postcodes[0] = p1; //Adding my objects already into the array of 25
        postcodes[1] = p2;
        postcodes[2] = p3;

        int people = 3; //Since we have 3 poeple already stored in the array

        while(people < 27)
        {
            System.out.println("ENTER YOUR FIRST NAME : ");
            String firstNameP = s.nextLine();
            if (firstNameP.equalsIgnoreCase("Done")) break; //I chose to use .equalsIgnoreCase so that no matter what cases the user uses to input , as long as it is done then it will break the loop

            System.out.println("ENTER YOUR LAST NAME : ");
            String lastNameP = s.nextLine();

            System.out.println("ENTER YOUR POSTCODE : ");
            String PostCodeP = s.nextLine();

            postcodes[people] = new PostCodeData(firstNameP,lastNameP,PostCodeP); // Adding the inputs into the array
            people++;
        }

        for(int i = 0 ; i < people ; i++) //Printing out all the objects created within the array in a loop until it reaches the amount that was inputted which is people
        {
            postcodes[i].printFirstName();
            postcodes[i].printLastName();
            postcodes[i].printPostCode();
            System.out.println();
        }
    }
}
