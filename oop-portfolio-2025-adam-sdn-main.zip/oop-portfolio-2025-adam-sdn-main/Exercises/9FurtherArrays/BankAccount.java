public class BankAccount {

    String Name;
    int accountNumber;
    double Balance;

    public BankAccount(String Name , int accountNumber , double Balance)
    {
        this.Name = Name;
        this.accountNumber = accountNumber;
        this.Balance = Balance;
    }

    public void setName(String name)
    {
        Name = name;
    }

    public String getName()
    {
        return Name;
    }

    public void printName()
    {
        System.out.println("Name : "+getName());
    }

    public void setAccountNumber(int accountNumber)
    {
        this.accountNumber = accountNumber;
    }

    public int getAccountNumber()
    {
        return accountNumber;
    }

    public void printAccountNumber()
    {
        System.out.println(getAccountNumber());
    }

    public void setBalance(double balance)
    {
        Balance = balance;
    }

    public double getBalance()
    {
        return Balance;
    }

    public void printBalance()
    {
        System.out.println("Initial Balance : "+getBalance());
    }

    public void Deposit(double deposit)
    {
        if(deposit > 0) //So that only a positive amount of money can be added rather tahn adding a negative amount and ending up being subtracted
        {
            Balance+=deposit;
            System.out.println("Your new balance now is : £"+getBalance());

        }
        else
        {
            System.out.println("An invalid amount was inputted"); //When the user puts a negative amount
        }
    }

    public void Withdraw(double withdraw)
    {
        if(getBalance() > withdraw)
        {
            Balance -= withdraw;
            System.out.println("Amount withdrawn from your balance : £ "+withdraw);
        }
        else
        {
            System.out.println("You do not have enough funds to withdraw that amount");
        }
    }

    public double bankFee()
    {
        return Balance*1.03; //An increase of 3% to the balance of the user
    }

    public void printbankFee()
    {
        System.out.println("Your new balance after a 3% bank fee is  : £ "+bankFee());
    }

}

