import java.util.Scanner; //to gain access to the scanner in the main class

public class QuizTime {


    public static void main (String[] args)
    {
        Quiz q = new Quiz();


        q.addQuestion(new QuestionInput("When did Leeds Beckett University establish ? ","1824"));
        q.addQuestion(new QuestionInput("When was Leeds United founded ?", "1919")); //you can keep adding questions as shown here as objects and it will keep going until it reaches 25 questions where it will stop giving you questions

        q.giveQuiz(); //This is so the questions can be given out
    }
}
