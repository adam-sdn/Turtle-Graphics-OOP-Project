public class Histogram {

    public static void main (String[] args)
    {
        int [][] values =
                {
                        {1 , 5 , 9},
                        {14 , 17},
                        {22 , 23 , 24 , 25 ,26 ,27},
                        {39},
                        {45 , 48 , 49},
                        {50, 51 , 55},
                        {67 , 68},
                        {73 , 74 , 75 ,77},
                        {81 , 89},
                        {90 , 94 , 99 , 100}
                }; // I created a ranomd amount of numbers in each array element (this will then be displayed as an array)

        String [] valueRanges =
                {
                        "1-10",
                        "11-20",
                        "21-30",
                        "31-40",
                        "41-50",
                        "51-60",
                        "61-70",
                        "71-80",
                        "81-90",
                        "91-100"
                }; // I had to make a seperate array so that I can headline the asterticks to its range


        for(int i = 0 ; i < values.length ; i++)
        {
            System.out.println(valueRanges[i]+" :"); // Repating the Range alongise the repeated astericks as requiested
            for(int j = 0 ; j < values[i].length; j++)
            {
                System.out.print("*");
            }
            System.out.println();
            System.out.println();
        }
    }
}
