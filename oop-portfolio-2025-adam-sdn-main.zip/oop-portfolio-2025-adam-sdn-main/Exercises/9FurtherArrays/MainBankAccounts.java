public class MainBankAccounts {

    public static void main (String[] args)
    {
        BankAccount b1 = new BankAccount("Timmy",102346 ,100874.99);
        BankAccount b2 = new BankAccount("Hannah",365498,87500.50);
        BankAccount b3 = new BankAccount("Adam",659879, 653218.13);

        BankAccount[] bankAccounts = {b1 , b2 , b3}; // I added the bank account objects into an array

        for ( BankAccount i : bankAccounts)
        {
            i.printName();
            i.printBalance();
            i.Deposit(3500); //depositing 35000 to all bank accounts objects
            i.Withdraw(100); //Withdraing 100 from all the objects
            i.printbankFee();
            System.out.println();
        }
    }
}