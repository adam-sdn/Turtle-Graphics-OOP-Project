public class QuestionInput {

    private String question; //So that it can only be accessed in this class only
    private String answer;

    public QuestionInput(String question , String answer)
    {
        this.question = question;
        this.answer = answer;
    }

    public String getQuestion()
    {
        return question;
    }

    public void setQuestion(String question)
    {
        this.question = question;
    }

    public String getAnswer()
    {
        return answer;
    }

    public void setAnswer(String answer)
    {
        this.answer = answer;
    }

    public boolean AnswerValid(String userAnswer)
    {
      return answer.trim().equalsIgnoreCase(userAnswer);
    }
}
